using Microsoft.Security.Copilot.Client.SkillContext;
using Microsoft.Security.Copilot.Skills.Attributes;

public class MySkills
{
    public async Task ComputeHashesAsync(ISkillContext context, CancellationToken cancellationToken)
    {
        // Get the value of the 'text' input parameter.
        SkillContextResponse contextResponse = await context.GetSkillContextAsync(cancellationToken);
        string text = contextResponse.Inputs["text"].Value;

        // Do the work.
        var result = new OutputSkillVariable(
            new
            {
                MD5Hash = BitConverter.ToString(System.Security.Cryptography.MD5.HashData(System.Text.Encoding.UTF8.GetBytes(text))).Replace("-", ""),
                SHA1Hash = BitConverter.ToString(System.Security.Cryptography.SHA1.HashData(System.Text.Encoding.UTF8.GetBytes(text))).Replace("-", ""),
                SHA256Hash = BitConverter.ToString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(text))).Replace("-", ""),
            });

        // (Optionally) Emit progress logs along the way.
        LogProgressRequest logProgressRequest = new()
        {
            Message = $"Successfully computed hashes for text: {text}"
        };
        await context.LogProgressAsync(logProgressRequest, cancellationToken);

        // Set the skill output.
        await context.SetSkillOutputAsync(result, cancellationToken);
    }
}